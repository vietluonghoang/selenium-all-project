## Summary of changes in version 4.12 [unreleased!]

We collect release notes in the wiki:
https://github.com/junit-team/junit/wiki/4.12-release-notes

This file will be updated right before release.
